using System;
using System.IO;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;
public static class KernelIoctl {
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] public static extern SafeFileHandle CreateFile(string path,uint access,uint share,IntPtr security,uint disposition,uint flags,IntPtr template);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool DeviceIoControl(SafeFileHandle handle,uint code,byte[] input,uint inputSize,byte[] output,uint outputSize,out uint returned,IntPtr overlap);
 public static int OpenError() { using(var h=CreateFile(@"\\.\VmDetectorKernel",0x80000000,3,IntPtr.Zero,3,0,IntPtr.Zero))return h.IsInvalid?Marshal.GetLastWin32Error():0; }
 public static void Test(string directory) {
  using(var h=CreateFile(@"\\.\VmDetectorKernel",0x80000000,3,IntPtr.Zero,3,0,IntPtr.Zero)) {
   if(h.IsInvalid)throw new Exception("Device open "+Marshal.GetLastWin32Error());
   byte[] bytes=new byte[4268];uint returned;
   if(!DeviceIoControl(h,0x83376000,null,0,bytes,(uint)bytes.Length,out returned,IntPtr.Zero)||returned!=bytes.Length)throw new Exception("Fixed probe failed "+Marshal.GetLastWin32Error());
   File.WriteAllBytes(Path.Combine(directory,"live-response.bin"),bytes);
   foreach(uint code in new uint[]{0x83376004,0x222000}) {
    for(int i=0;i<bytes.Length;i++)bytes[i]=0xa5;
    bool ok=DeviceIoControl(h,code,null,0,bytes,(uint)bytes.Length,out returned,IntPtr.Zero);
    int error=Marshal.GetLastWin32Error();
    if(ok||error!=1)throw new Exception("Unknown IOCTL code="+code.ToString("X")+" success="+ok+" error="+error+" bytes="+returned);
    foreach(byte b in bytes)if(b!=0xa5)throw new Exception("Error response changed output buffer");
   }
   if(DeviceIoControl(h,0x83376000,new byte[]{1},1,bytes,(uint)bytes.Length,out returned,IntPtr.Zero)||Marshal.GetLastWin32Error()!=87)throw new Exception("Input accepted");
   if(DeviceIoControl(h,0x83376000,null,0,bytes,1,out returned,IntPtr.Zero)||Marshal.GetLastWin32Error()!=122)throw new Exception("Short output accepted");
  }
  File.WriteAllText(Path.Combine(directory,"ioctl-controls.txt"),"PASS fixed-size live probe; unknown IOCTLs rejected; input rejected; short output rejected; unknown-IOCTL output buffer unchanged");
 }
}

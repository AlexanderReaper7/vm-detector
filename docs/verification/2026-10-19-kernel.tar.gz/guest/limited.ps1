$ErrorActionPreference='Stop'
$p='C:\adversary\work\vm-detector-kernel-20261019'
Add-Type -Path "$p\ioctl.cs"
$admin=([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
$code=[KernelIoctl]::OpenError()
[IO.File]::WriteAllText("$p\limited.json",(@{administrator=$admin;open_error=$code} | ConvertTo-Json))
if($admin -or $code -ne 5){throw 'Restricted-user device-access test failed'}

$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$p='C:\adversary\work\vm-detector-kernel-20261019'
Start-Transcript "$p\prepare.txt" -Force
try {
 if((Get-FileHash "$p\vm-detector.exe").Hash -ne 'ABCD567B34A1D5A59FC3B7E9E82B335559213BD317CABFFD93183C1AABDC7479'){throw 'Executable hash mismatch'}
 if((Get-FileHash "$p\vm-detector-kernel.sys").Hash -ne '5E4990AB9C226B3DAB933BC38B35BF3E98506F9E64F05193C3C34D756F911B7E'){throw 'Unsigned driver hash mismatch'}
 function Run-Detector($arguments,$name) {
  $si=New-Object Diagnostics.ProcessStartInfo
  $si.FileName="$p\vm-detector.exe";$si.Arguments=$arguments;$si.UseShellExecute=$false;$si.CreateNoWindow=$true
  $si.RedirectStandardInput=$true;$si.RedirectStandardOutput=$true;$si.RedirectStandardError=$true
  $proc=[Diagnostics.Process]::Start($si);$proc.StandardInput.Close()
  $stdout=$proc.StandardOutput.ReadToEnd();$stderr=$proc.StandardError.ReadToEnd();$proc.WaitForExit()
  [IO.File]::WriteAllText("$p\$name.txt",$stdout+$stderr)
  if($proc.ExitCode -ne 0){throw "Detector exit $($proc.ExitCode)"}
 }
 Run-Detector '--check KERNEL' 'missing-driver'
 Run-Detector '--check QEMU' 'user-mode'
 $cert=Get-Item Cert:\LocalMachine\My\D790063D5BF1858732C0591A5352B55199A00C3B
 Set-AuthenticodeSignature "$p\vm-detector-kernel.sys" $cert -HashAlgorithm SHA256 | Format-List Status,StatusMessage,Path
 Get-FileHash "$p\vm-detector-kernel.sys" | Format-List | Out-File "$p\signed-hash.txt"
 bcdedit /set '{current}' testsigning on
 if($LASTEXITCODE){throw 'Cannot enable test signing'}
 [IO.File]::WriteAllText("$p\prepared.txt",'ready')
} catch { $_ | Out-String | Set-Content "$p\error.txt";throw }
finally { Stop-Transcript }

$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$p='C:\adversary\work\vm-detector-kernel-20261019'
Start-Transcript "$p\verify.txt" -Force
try {
 if(!(Get-Service VmDetectorKernel -ErrorAction SilentlyContinue)){
  sc.exe create VmDetectorKernel type= kernel start= demand binPath= "$p\vm-detector-kernel.sys"
  if($LASTEXITCODE){throw 'Create driver service failed'}
 }
 if((Get-Service VmDetectorKernel).Status -ne 'Running'){
  sc.exe start VmDetectorKernel
  if($LASTEXITCODE){throw 'Driver load failed'}
 }
 driverquery.exe /v /fo csv | Select-String VmDetectorKernel | Set-Content "$p\driver-loaded.txt"
 Add-Type -Path "$p\ioctl.cs"
 [KernelIoctl]::Test($p)
 $si=New-Object Diagnostics.ProcessStartInfo
 $si.FileName="$p\vm-detector.exe";$si.Arguments='--check QEMU --check KERNEL';$si.UseShellExecute=$false;$si.CreateNoWindow=$true
 $si.RedirectStandardInput=$true;$si.RedirectStandardOutput=$true;$si.RedirectStandardError=$true
 $proc=[Diagnostics.Process]::Start($si);$proc.StandardInput.Close()
 $stdout=$proc.StandardOutput.ReadToEnd();$stderr=$proc.StandardError.ReadToEnd();$proc.WaitForExit()
 [IO.File]::WriteAllText("$p\loaded.txt",$stdout+$stderr)
 if($proc.ExitCode){throw "Detector exit $($proc.ExitCode)"}
 if($stdout -notmatch 'VM-K01.*GOOD' -or $stdout -notmatch 'VM-K02.*GOOD' -or $stdout -notmatch 'VM-C01.*OBS'){throw 'Wrong kernel results'}
 [IO.File]::WriteAllText("$p\verified.txt",'ready for restricted-user test and cleanup')
} catch { $_ | Out-String | Set-Content "$p\error.txt";throw }
finally { Stop-Transcript }

$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$p='C:\adversary\work\vm-detector-kernel-20261019'
Start-Transcript "$p\cleanup.txt" -Force
sc.exe stop VmDetectorKernel
if($LASTEXITCODE){throw 'Driver stop failed'}
sc.exe delete VmDetectorKernel
if($LASTEXITCODE){throw 'Driver service deletion failed'}
foreach($name in @('vmd-kernel-prepare','vmd-kernel-verify','vmd-kernel-limited')){Unregister-ScheduledTask -TaskName $name -Confirm:$false}
bcdedit /deletevalue '{current}' testsigning
if($LASTEXITCODE){throw 'Test-signing restoration failed'}
Stop-Transcript
shutdown.exe /r /t 5 /f

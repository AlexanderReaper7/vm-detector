$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$p='C:\adversary\work\vm-detector-kernel-20261019'
Add-Type -Path C:\adversary\work\gpt-6.1-sol-kernel-20261019-1233\src\security.cs
$ci=[CIState]::Read()
$bcd=bcdedit /enum '{current}' | Out-String
$guard=Get-CimInstance -Namespace root\Microsoft\Windows\DeviceGuard -ClassName Win32_DeviceGuard
$loaded=driverquery.exe /v /fo csv | Out-String
$result=[ordered]@{boot=(Get-CimInstance Win32_OperatingSystem).LastBootUpTime.ToString('o');ci=$ci;secure_boot=(Confirm-SecureBootUEFI);testsigning=[bool]($bcd -match '\btestsigning\b');nointegritychecks=[bool]($bcd -match '\bnointegritychecks\b');vbs=$guard.VirtualizationBasedSecurityStatus;services_running=@($guard.SecurityServicesRunning);driver_registry=(Test-Path HKLM:\SYSTEM\CurrentControlSet\Services\VmDetectorKernel);driver_loaded=[bool]($loaded -match 'VmDetectorKernel');tasks=@(Get-ScheduledTask -TaskName vmd-kernel-* -ErrorAction SilentlyContinue | ForEach-Object TaskName)}
[IO.File]::WriteAllText("$p\final.json",($result | ConvertTo-Json -Depth 4))
if($ci -notmatch 'options=0x00000001' -or $result.secure_boot -or $result.testsigning -or $result.nointegritychecks -or $result.vbs -or $result.driver_registry -or $result.driver_loaded -or $result.tasks.Count){throw 'Final-state check failed'}
$result | ConvertTo-Json -Depth 4

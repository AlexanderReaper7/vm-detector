$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$p='C:\adversary\work\network-deploy-20261020'
Start-Transcript "$p\cleanup.txt" -Force
try {
sc.exe stop VmDetectorKernel
if($LASTEXITCODE){throw 'Stop driver failed'}
sc.exe delete VmDetectorKernel
if($LASTEXITCODE){throw 'Delete service failed'}
bcdedit /deletevalue '{current}' testsigning
if($LASTEXITCODE){throw 'Restore signing failed'}
foreach($n in @('vmd-network-before','vmd-network-prepare','vmd-network-verify','vmd-network-export','vmd-network-cleanup')){Unregister-ScheduledTask -TaskName $n -Confirm:$false -ErrorAction SilentlyContinue}
} finally {Stop-Transcript}
shutdown.exe /r /t 5
#!/usr/bin/env python3
"""Check dnsmasq's real UDP/TCP metadata replies on isolated loopback ports."""
import argparse
import json
import socket
import struct
import subprocess
import tempfile
import time
from pathlib import Path
import xml.etree.ElementTree as ET


def name_end(data, offset):
    for _ in range(128):
        assert offset < len(data), 'truncated DNS name'
        n = data[offset]
        if n & 0xc0 == 0xc0:
            assert offset + 1 < len(data)
            return offset + 2
        assert n <= 63
        offset += n + 1
        if not n:
            return offset
    raise AssertionError('unbounded DNS name')


def receive_exact(sock, count):
    data = b''
    while len(data) < count:
        chunk = sock.recv(count - len(data))
        assert chunk, 'truncated TCP DNS response'
        data += chunk
    return data


def query(port, name, qtype, qclass, tcp):
    question = b''.join(bytes([len(p)]) + p.encode() for p in name.split('.')) + b'\0' + struct.pack('!HH', qtype, qclass)
    request = struct.pack('!6H', 0x7ad3, 0x100, 1, 0, 0, 0) + question
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM if tcp else socket.SOCK_DGRAM) as s:
        s.settimeout(2)
        s.connect(('192.168.1.1', port))
        s.sendall(struct.pack('!H', len(request)) + request if tcp else request)
        data = receive_exact(s, struct.unpack('!H', receive_exact(s, 2))[0]) if tcp else s.recv(4096)
    assert len(data) >= 12 and data[:2] == request[:2]
    _, flags, qd, an, ns, ar = struct.unpack_from('!6H', data)
    assert flags & 0x8000 and not flags & 0x200 and qd == 1
    offset = name_end(data, 12) + 4
    assert data[12:offset] == question, 'DNS question was not preserved'
    answers = []
    for _ in range(an):
        offset = name_end(data, offset)
        assert offset + 10 <= len(data)
        typ, cls, ttl, length = struct.unpack_from('!HHIH', data, offset)
        offset += 10
        value = data[offset:offset + length]
        assert len(value) == length
        answers.append((typ, cls, value))
        offset += length
    return {'name': name, 'tcp': tcp, 'rcode': flags & 15, 'answers': an,
            'request_hex': request.hex(), 'response_hex': data.hex()}, answers


def control(port, tcp):
    row, answers = query(port, 'svm-control.test', 1, 1, tcp)
    assert row['rcode'] == 0 and (1, 1, bytes([192, 0, 2, 7])) in answers, row


records=[]
for tcp in (False,True):
    for name in ('version.bind','authors.bind','servers.bind'):
        for stage in ('before','after'):
            row,answers=query(53,'example.com',1,1,tcp)
            assert row['rcode']==0 and any(t==1 and c==1 and len(v)==4 for t,c,v in answers),row
            row['control_stage']=stage;records.append(row)
            if stage=='before':
                row,answers=query(53,name,16,3,tcp)
                assert row['rcode'] in (0,3,4,5) and row['answers']==0,row
                records.append(row)
Path(__file__).with_name('dns-live.json').write_text(json.dumps(records,indent=2)+'\n')
print('PASS six valid UDP/TCP metadata replies with no answers; ordinary DNS passed before and after each query')

using System;
using System.IO;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;
public static class NetworkIoctl {
 [DllImport("kernel32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern SafeFileHandle CreateFile(string path,uint access,uint share,IntPtr security,uint disposition,uint flags,IntPtr template);
 [DllImport("kernel32.dll",SetLastError=true)] static extern bool DeviceIoControl(SafeFileHandle h,uint code,byte[] input,uint inputSize,byte[] output,uint outputSize,out uint returned,IntPtr overlap);
 public static void Run(string directory) {
  using(var h=CreateFile(@"\\.\VmDetectorKernel",0x80000000,3,IntPtr.Zero,3,0,IntPtr.Zero)) {
   if(h.IsInvalid)throw new Exception("Device open "+Marshal.GetLastWin32Error());
   foreach(uint code in new uint[]{0x83376004,0x83376000}) {
    byte[] bytes=new byte[code==0x83376004?804:4268];uint returned;
    if(!DeviceIoControl(h,code,null,0,bytes,(uint)bytes.Length,out returned,IntPtr.Zero)||returned!=bytes.Length)throw new Exception("Probe failed "+Marshal.GetLastWin32Error()+" bytes="+returned);
    File.WriteAllBytes(Path.Combine(directory,code==0x83376004?"network-response.bin":"kernel-response.bin"),bytes);
    if((BitConverter.ToUInt32(bytes,8)&3)!=0)throw new Exception("Probe did not report CPL0");
    if(code==0x83376004 && BitConverter.ToUInt32(bytes,16)!=0)throw new Exception("Network query status "+BitConverter.ToUInt32(bytes,16).ToString("X"));
    if(DeviceIoControl(h,code,new byte[]{1},1,bytes,(uint)bytes.Length,out returned,IntPtr.Zero)||Marshal.GetLastWin32Error()!=87)throw new Exception("Input accepted");
    if(DeviceIoControl(h,code,null,0,bytes,1,out returned,IntPtr.Zero)||Marshal.GetLastWin32Error()!=122)throw new Exception("Short output accepted");
   }
   byte[] invalid=new byte[804];uint count;
   if(DeviceIoControl(h,0x222000,null,0,invalid,804,out count,IntPtr.Zero)||Marshal.GetLastWin32Error()!=1)throw new Exception("Unknown IOCTL accepted");
  }
  File.WriteAllText(Path.Combine(directory,"ioctl-controls.txt"),"PASS both live CPL0 responses; nonempty input, short output and unknown IOCTL rejected");
 }
}

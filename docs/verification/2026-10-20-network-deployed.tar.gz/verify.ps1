$ErrorActionPreference='Stop';$ProgressPreference='SilentlyContinue'
$p='C:\adversary\work\network-deploy-20261020'
Start-Transcript "$p\verify.txt" -Force
try {
if([Security.Principal.WindowsIdentity]::GetCurrent().Name -ne 'NT AUTHORITY\SYSTEM'){throw 'SYSTEM required'}
if((Get-FileHash "$p\vm-detector-kernel.sys").Hash -ne '2D8DFFB4E9D84DB9A4926211A26695A5185A8D7F560E691FBF5B7E2293E83FF3'){throw 'Signed driver hash mismatch'}
sc.exe create VmDetectorKernel type= kernel start= demand binPath= "$p\vm-detector-kernel.sys"
if($LASTEXITCODE){throw 'Service create failed'}
sc.exe start VmDetectorKernel
if($LASTEXITCODE){throw 'Driver load failed'}
driverquery.exe /v /fo csv | Select-String VmDetectorKernel | Set-Content "$p\driver-loaded.txt"
Add-Type -Path "$p\network-ioctl.cs"
[NetworkIoctl]::Run($p)
$si=New-Object Diagnostics.ProcessStartInfo
$si.FileName="$p\vm-detector.exe";$si.Arguments='--check QEMU --check KERNEL --check NETKERNEL';$si.UseShellExecute=$false;$si.CreateNoWindow=$true
$si.RedirectStandardInput=$true;$si.RedirectStandardOutput=$true;$si.RedirectStandardError=$true
$proc=[Diagnostics.Process]::Start($si);$proc.StandardInput.Close()
$stdout=$proc.StandardOutput.ReadToEnd();$stderr=$proc.StandardError.ReadToEnd();$proc.WaitForExit()
[IO.File]::WriteAllText("$p\detector-loaded.txt",$stdout+$stderr)
if($proc.ExitCode){throw "Detector exit $($proc.ExitCode)"}
foreach($id in @('NET-VM-01','NET-VM-02','VM-K01','VM-K02')){if($stdout -notmatch "$id.*GOOD"){throw "Expected GOOD $id"}}
if($stdout -match 'NET-C02|NET-CLUE-01'){throw 'Network mismatch or template clue remains'}
& C:\adversary\work\gpt-6.1-sol-20261019-171800\bin\python\python.exe "$p\dns-live.py" | Tee-Object "$p\dns-live.txt"
if($LASTEXITCODE){throw 'Live DNS verification failed'}
Get-NetAdapter | Format-List Name,InterfaceDescription,Status,MacAddress,LinkSpeed
Get-PnpDevice -Class Net -PresentOnly | Select-Object Status,FriendlyName,InstanceId | ConvertTo-Json | Set-Content "$p\nic-pnp.json"
[IO.File]::WriteAllText("$p\verified.txt",'PASS live driver and DNS checks')
} catch {$_ | Out-String | Set-Content "$p\verify-error.txt";throw} finally {Stop-Transcript}
